<?php
$objUsuario = new Usuario("masa@correo.com", "123");
$controlUsuario = new ControlUsuario($objUsuario);
?>